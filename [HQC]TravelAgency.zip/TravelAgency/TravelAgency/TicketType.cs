﻿namespace TravelAgency
{
    public enum TicketType
    {
        Bus,
        Flight,
        Train
    }
}