﻿using System;

class BitTowerOfDoom
{
    static void Main()
    {
       
    }
}
