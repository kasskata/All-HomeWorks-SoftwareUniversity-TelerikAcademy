﻿using System;

class BinaryDigits
{
    static void Main()
    {
        int numberN = int.Parse(Console.ReadLine());
        string numberNstr = Convert.ToString(numberN,2).PadLeft(32,'0');

        if (numberNstr.Length>16)
        {
            numberNstr = numberNstr.Remove(0, 16);
        }

        for (int j = 0; j < 4; j++)
        {
            for (int i = 0; i < numberNstr.Length; i++)
            {
                if (numberNstr[i] == '1')
                {                   
                    if (i==15)
                    {
                        if (j==0)
                        {
                            Console.WriteLine(".#.");
                        }
                        else if (j==1)
                        {
                            Console.WriteLine("##.");
                        }
                        else if (j==2)
                        {
                            Console.WriteLine(".#.");
                        }
                        else if (j==3)
                        {
                            Console.WriteLine("###");
                        }                       
                    }
                    else if (i!=15)
                    {
                        if (j==0)
                        {
                            Console.Write(".#..");
                        }
                        else if (j==1)
                        {
                            Console.Write("##..");
                        }
                        else if (j==2)
                        {
                            Console.Write(".#..");
                        }
                        else if (j == 3)
                        {
                            Console.Write("###.");
                        }
                    }
                }
                else if(numberNstr[i] =='0')
                {
                    if (i == 15)
                    {
                        if (j == 0)
                        {
                            Console.WriteLine("###");
                        }
                        else if (j == 1)
                        {
                            Console.WriteLine("#.#");
                        }
                        else if (j == 2)
                        {
                            Console.WriteLine("#.#");
                        }
                        else if (j == 3)
                        {
                            Console.WriteLine("###");
                        }
                    }
                    else if (i != 15)
                    {
                        if (j==0)
                        {
                            Console.Write("###.");
                        }
                        else if (j==1)
                        {
                            Console.Write("#.#.");
                        }
                        else if (j==2)
                        {
                            Console.Write("#.#.");
                        }
                        else if (j==3)
                        {
                            Console.Write("###.");
                        }
                    }
                }
            }
        }
    }
}
